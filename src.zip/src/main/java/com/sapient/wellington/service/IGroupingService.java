package com.sapient.wellington.service;

import com.sapient.wellington.pojo.Order;

public interface IGroupingService {

	void processOrderForGrouping(Order order);

}

package com.sapient.wellington.filereader;

public interface FileReader {
	void readFile(int noOfFiles, String filePath) throws Exception;
}

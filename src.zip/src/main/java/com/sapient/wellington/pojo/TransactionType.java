package com.sapient.wellington.pojo;

public enum TransactionType {
	BUY, SELL
}
